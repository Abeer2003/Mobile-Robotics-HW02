#!/usr/bin/env python3
"""Plot the ten UMBmark end points, the two centres of gravity and the predicted points.

    python3 umbmark_plot.py                    # reads umbmark.csv, writes umbmark_endpoints.png

"""
import argparse
import math

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument('--csv', default='umbmark.csv')
ap.add_argument('--out', default='umbmark_endpoints.png')
ap.add_argument('--side', type=float, default=2.0)
a = ap.parse_args()

# Predicted centres of gravity, exactly as in the results table: (eps_x, eps_y, eps_theta)
PREDICTED = {'cw': (-0.387, -0.387, 0.387),
             'ccw': (-0.190, 0.190, -0.190)}


d = pd.read_csv(a.csv)
col = {'cw': '#2a78d6', 'ccw': '#eb6834'}
INK, MUTED, GRID = '#0b0b0b', '#52514e', '#e4e3df'
PRED_ARROW = '#7a2fb8'   # predicted heading arrows, distinct from the CW / CCW colours

fig = plt.figure(figsize=(9.6, 10.4))
gs = fig.add_gridspec(2, 2, height_ratios=[1.55, 1], hspace=0.28, wspace=0.28)
ax = fig.add_subplot(gs[0, :])
zooms = {'cw': fig.add_subplot(gs[1, 0]), 'ccw': fig.add_subplot(gs[1, 1])}
rows = []


def heading(a_, x_, y_, th, length, color, lw=1.6, alpha=1.0, z=7):
    """Arrow at (x_, y_) pointing at angle th (rad) from +x: the robot's final heading."""
    a_.annotate('', xy=(x_ + length * math.cos(th), y_ + length * math.sin(th)), xytext=(x_, y_),
                arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, alpha=alpha,
                                shrinkA=0, shrinkB=0, mutation_scale=11), zorder=z)


def style(a_):
    a_.grid(True, color=GRID, lw=0.8); a_.set_axisbelow(True)
    for s_ in ('top', 'right'):
        a_.spines[s_].set_visible(False)
    a_.tick_params(colors=MUTED)


for name, sign in (('cw', -1), ('ccw', 1)):
    g = d[d.direction == name]
    x, y = g.eps_x.values, g.eps_y.values
    cgx, cgy = x.mean(), y.mean()
    px, py, pth = PREDICTED[name]
    c = col[name]
    # overview: points are tiny relative to the axes, so mark the CG as an open ring
    ax.scatter(x, y, s=26, color=c, zorder=4, label=f'{name.upper()} end points (5)')
    ax.scatter(cgx, cgy, s=420, marker='o', facecolor='none', edgecolor=c, linewidth=2.2,
               zorder=5, label=f'{name.upper()} centre of gravity')
    ax.scatter(px, py, s=150, marker='X', color='white', edgecolor=c, linewidth=2.2,
               zorder=6, label=f'{name.upper()} predicted')
    heading(ax, cgx, cgy, g.eps_theta.mean(), 0.07, c)
    heading(ax, px, py, pth, 0.07, PRED_ARROW, lw=1.8)
    # zoom panel on the cluster
    z = zooms[name]
    half = max(0.003, 1.8 * max(np.abs(x - cgx).max(), np.abs(y - cgy).max()))
    z.scatter(x, y, s=70, color=c, zorder=4)
    for i, (xi, yi) in enumerate(zip(x, y), 1):
        z.annotate(str(i), (xi, yi), xytext=(5, 5), textcoords='offset points', fontsize=8, color=MUTED)
    for xi, yi, ti in zip(x, y, g.eps_theta.values):
        heading(z, xi, yi, ti, 0.55 * half, c, lw=1.2, alpha=0.8)
    heading(z, cgx, cgy, g.eps_theta.mean(), 0.55 * half, INK, lw=1.6)
    z.scatter(cgx, cgy, s=260, marker='o', facecolor='none', edgecolor=c, linewidth=2.2, zorder=5)
    z.scatter(cgx, cgy, s=22, marker='+', color=INK, zorder=6)
    z.set_xlim(cgx - half, cgx + half); z.set_ylim(cgy - half, cgy + half)
    z.set_aspect('equal', adjustable='box')
    z.set_title(f'{name.upper()}: end points, centre of gravity and headings (zoom)', loc='left', fontsize=10, color=INK)
    z.set_xlabel('eps_x (m)', color=MUTED); z.set_ylabel('eps_y (m)', color=MUTED)
    style(z)
    rows.append((name, len(g), cgx, cgy, math.hypot(cgx, cgy), px, py,
                 g.eps_theta.mean(), pth))
ax.axhline(0, color=GRID, lw=1); ax.axvline(0, color=GRID, lw=1)
ax.scatter(0, 0, marker='+', s=120, color=INK, zorder=2)
ax.annotate('start / odometry end (0, 0)', (0, 0), xytext=(8, 10), textcoords='offset points',
            fontsize=9, color=MUTED)
ax.set_aspect('equal', adjustable='datalim')
ax.set_xlabel('eps_x (m): true - odometry, in the start frame', color=MUTED)
ax.set_ylabel('eps_y (m)', color=MUTED)
style(ax)
ax.legend(frameon=False, fontsize=9, loc='center left', bbox_to_anchor=(0.02, 0.5))
ax.set_title('UMBmark end points, nameplate odometry (P06): measured vs predicted',
             loc='left', fontsize=11, color=INK)
ax.text(0.99, 0.97, 'Arrows: final heading (eps_theta)\nblue / orange = measured, purple = predicted',
        transform=ax.transAxes, fontsize=9, color=MUTED, va='top', ha='right')
fig.savefig(a.out, dpi=160, bbox_inches='tight')

print(f'{"dir":4} {"n":>2} {"CG x":>9} {"CG y":>9} {"|CG|":>8} | {"pred x":>8} {"pred y":>8} (m) | {"CG th":>9} {"pred th":>8} (rad)')
for r in rows:
    print(f'{r[0]:4} {r[1]:2d} {r[2]:9.5f} {r[3]:9.5f} {r[4]:8.5f} | {r[5]:8.3f} {r[6]:8.3f}     | {r[7]:9.6f} {r[8]:8.3f}')
print('wrote', a.out)
