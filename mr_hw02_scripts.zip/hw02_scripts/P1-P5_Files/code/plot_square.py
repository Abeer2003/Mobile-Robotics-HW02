#!/usr/bin/env python3
"""Plot commanded square vs /odom vs ground truth for each robot (3 laps each).

    python3 plot_square.py                      # REF and P06, L = 2 m, ccw
    python3 plot_square.py --L 2 --out squares.png
"""
import argparse

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument('--L', type=float, default=2.0, help='side length used in the run (m)')
ap.add_argument('--runs', nargs='+', default=['REF:REF_square_ccw.csv', 'P06:P06_square_ccw.csv'],
                help='label:csv pairs')
ap.add_argument('--out', default='square_paths.png')
a = ap.parse_args()

INK, MUTED, GRID = '#0b0b0b', '#52514e', '#e4e3df'
C_ODOM, C_GT, C_CMD = '#2a78d6', '#eb6834', '#8a8984'

L = a.L
cmd = np.array([[0, 0], [L, 0], [L, L], [0, L], [0, 0]])   # ccw, starting at the origin facing +x

fig, axes = plt.subplots(1, len(a.runs), figsize=(5.6 * len(a.runs), 6.2), sharex=True, sharey=True)
axes = np.atleast_1d(axes)
for ax, run in zip(axes, a.runs):
    label, path = run.split(':', 1)
    d = pd.read_csv(path)
    ax.plot(cmd[:, 0], cmd[:, 1], '--', color=C_CMD, lw=1.6, label='Commanded square', zorder=1)
    ax.plot(d.odom_x, d.odom_y, '-', color=C_ODOM, lw=1.5, label='/odom (belief)', zorder=2)
    ax.plot(d.gt_x, d.gt_y, '-', color=C_GT, lw=1.5, label='Ground truth', zorder=3)
    ax.plot(0, 0, 'o', ms=8, mfc='white', mec=INK, mew=1.6, zorder=4)
    ax.annotate('start', (0, 0), xytext=(8, -14), textcoords='offset points', fontsize=9, color=MUTED)
    for x, y, c in ((d.odom_x.iloc[-1], d.odom_y.iloc[-1], C_ODOM),
                    (d.gt_x.iloc[-1], d.gt_y.iloc[-1], C_GT)):
        ax.plot(x, y, 's', ms=8, color=c, mec='white', mew=1.5, zorder=5)
    end_gt = np.hypot(d.gt_x.iloc[-1], d.gt_y.iloc[-1])
    end_od = np.hypot(d.odom_x.iloc[-1], d.odom_y.iloc[-1])
    ax.set_title(f'{label}: 3 laps, end point {100 * end_gt:.1f} cm (true), '
                 f'{100 * end_od:.1f} cm (odom) from start', fontsize=10.5, color=INK, loc='left')
    ax.set_aspect('equal', adjustable='box')
    ax.grid(True, color=GRID, lw=0.8)
    ax.set_axisbelow(True)
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    ax.set_xlabel('x (m)', color=MUTED)
    ax.tick_params(colors=MUTED)
axes[0].set_ylabel('y (m)', color=MUTED)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc='lower center', ncol=3, frameon=False, fontsize=10, bbox_to_anchor=(0.5, -0.005))
fig.suptitle(f'Open-loop square, L = {L:g} m, counter-clockwise: commanded vs believed vs true',
             x=0.01, ha='left', fontsize=12, color=INK)
fig.tight_layout(rect=(0, 0.08, 1, 0.96))
fig.savefig(a.out, dpi=160)
print('wrote', a.out)
