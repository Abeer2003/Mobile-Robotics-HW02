#!/usr/bin/env python3
"""open_loop_square.py - drive a square OPEN LOOP, timed by the node clock.

Publishes (v, omega) on /cmd_vel as a fixed sequence of timed segments:

    4 x laps x [ straight for L / v seconds,  rotate for (pi/2) / omega seconds ]
    [linear velocity, angular velocity] essentially

No feedback is used: durations are computed once, from the parameters, and
the segment boundaries are measured on self.get_clock() (simulation time
when use_sim_time is true). Whatever the robot really does, it does.

Parameters:
    L          side length (m)                       default 2.0
    v          forward speed (m/s)                   default 0.2
    omega      turn rate magnitude (rad/s)           default 0.5
    direction  'ccw' or 'cw'                         default 'ccw'
    laps       number of times to drive the square   default 1
    csv        output file                           default open_loop_square.csv
    settle     seconds to keep logging after the last segment   default 2.0
    log_rate   CSV rows per second                   default 20.0

CSV columns (one row per log tick, t = seconds since the first segment began,
poses are the raw messages: /odom is in the odom frame, /ground_truth/odom in
the world frame):

    t, phase, odom_x, odom_y, odom_yaw, gt_x, gt_y, gt_yaw
"""



import csv
import math

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node


def yaw_of(msg):
    q = msg.pose.pose.orientation
    return math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                      1.0 - 2.0 * (q.y * q.y + q.z * q.z))


def pose_of(msg):
    p = msg.pose.pose.position
    return (p.x, p.y, yaw_of(msg))


class OpenLoopSquare(Node):
    def __init__(self):
        super().__init__('open_loop_square')
        self.L = float(self.declare_parameter('L', 2.0).value)
        self.v = float(self.declare_parameter('v', 0.2).value)
        self.omega = abs(float(self.declare_parameter('omega', 0.5).value))
        direction = str(self.declare_parameter('direction', 'ccw').value).lower()
        laps = int(self.declare_parameter('laps', 1).value)
        self.csv_path = str(self.declare_parameter('csv', 'open_loop_square.csv').value)
        self.settle = float(self.declare_parameter('settle', 2.0).value)
        log_rate = float(self.declare_parameter('log_rate', 20.0).value)

        if direction not in ('ccw', 'cw'):
            raise ValueError(f"direction must be 'ccw' or 'cw', got '{direction}'")
        if laps < 1:
            raise ValueError(f'laps must be >= 1, got {laps}')
        if self.L <= 0.0 or self.v <= 0.0 or self.omega <= 0.0 or log_rate <= 0.0:
            raise ValueError('L, v, omega and log_rate must all be > 0')
        self.sign = 1.0 if direction == 'ccw' else -1.0

        # Segment schedule: (name, v, omega, duration). Boundaries are
        # cumulative from the start time, so tick quantisation does not
        # accumulate from segment to segment.
        t_straight = self.L / self.v
        t_turn = (math.pi / 2.0) / self.omega
        self.segments = []
        for i in range(4 * laps):
            self.segments.append((f'straight{i + 1}', self.v, 0.0, t_straight))
            self.segments.append((f'turn{i + 1}', 0.0, self.sign * self.omega, t_turn))
        self.ends = []
        total = 0.0
        for seg in self.segments:
            total += seg[3]
            self.ends.append(total)
        self.total = total

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.create_subscription(Odometry, '/odom', self.on_odom, 50)
        self.create_subscription(Odometry, '/ground_truth/odom', self.on_gt, 50)
        self.odom = self.gt = None

        self.file = open(self.csv_path, 'w', newline='')
        self.writer = csv.writer(self.file)
        self.writer.writerow(['t', 'phase', 'odom_x', 'odom_y', 'odom_yaw',
                              'gt_x', 'gt_y', 'gt_yaw'])

        self.t0 = None            # rclpy Time of the first segment
        self.done = False
        self.last_log = None
        self.log_period = 1.0 / log_rate
        self.create_timer(0.01, self.tick)   # uses this node's clock

        self.get_logger().info(
            f'{direction}: {laps} lap(s), L={self.L:g} m, v={self.v:g} m/s, omega={self.omega:g} rad/s '
            f'-> {t_straight:.2f} s per side, {t_turn:.2f} s per turn, '
            f'{self.total:.1f} s total. Waiting for /odom and /ground_truth/odom ...')

    def on_odom(self, msg):
        self.odom = pose_of(msg)

    def on_gt(self, msg):
        self.gt = pose_of(msg)

    def tick(self):
        if self.done or self.odom is None or self.gt is None:
            return
        now = self.get_clock().now()
        if self.t0 is None:
            self.t0 = now
            self.get_logger().info('Started.')
        t = (now - self.t0).nanoseconds * 1e-9

        cmd = Twist()
        phase = 'settle'
        if t < self.total:
            idx = next(i for i, e in enumerate(self.ends) if t < e)
            name, cmd.linear.x, cmd.angular.z, _ = self.segments[idx]
            phase = name
        self.cmd_pub.publish(cmd)   # zero Twist once the sequence is over

        if self.last_log is None or t - self.last_log >= self.log_period - 1e-9:
            self.last_log = t
            self.writer.writerow([f'{t:.3f}', phase,
                                  *(f'{x:.5f}' for x in self.odom),
                                  *(f'{x:.5f}' for x in self.gt)])

        if t >= self.total + self.settle:
            self.finish(t)

    def finish(self, t):
        self.done = True
        self.cmd_pub.publish(Twist())
        self.file.close()
        self.get_logger().info(f'Done after {t:.2f} s; wrote {self.csv_path}')
        raise SystemExit


def main():
    rclpy.init()
    node = OpenLoopSquare()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        try:
            node.cmd_pub.publish(Twist())
        except Exception:
            pass
        if not node.file.closed:
            node.file.close()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
