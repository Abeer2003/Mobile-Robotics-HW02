#!/usr/bin/env python3
"""arc_drive.py - drive a constant-(v, omega) arc for a fixed time, then stop.

    ros2 run a2_description arc_drive.py --ros-args -p use_sim_time:=true \
        -p v:=0.2 -p omega:=0.2 -p duration:=30.0

The duration is measured on the node's clock (simulation time with
use_sim_time:=true), so it does not depend on the simulation's speed.
"""
import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node


class ArcDrive(Node):
    def __init__(self):
        super().__init__('arc_drive')
        self.v = float(self.declare_parameter('v', 0.2).value)
        self.omega = float(self.declare_parameter('omega', 0.2).value)
        self.duration = float(self.declare_parameter('duration', 30.0).value)
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.t0 = None
        self.create_timer(0.02, self.tick)

    def tick(self):
        now = self.get_clock().now()
        if now.nanoseconds == 0:           # waiting for /clock
            return
        if self.t0 is None:
            self.t0 = now
            self.get_logger().info(
                f'Arc: v={self.v:g} m/s, omega={self.omega:g} rad/s for {self.duration:g} s')
        t = (now - self.t0).nanoseconds * 1e-9
        cmd = Twist()
        if t < self.duration:
            cmd.linear.x, cmd.angular.z = self.v, self.omega
        self.pub.publish(cmd)
        if t >= self.duration:
            self.get_logger().info('Done; robot stopped.')
            raise SystemExit


def main():
    rclpy.init()
    node = ArcDrive()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        try:
            node.pub.publish(Twist())
        except Exception:
            pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
