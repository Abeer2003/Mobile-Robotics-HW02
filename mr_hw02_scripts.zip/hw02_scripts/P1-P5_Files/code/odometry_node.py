#!/usr/bin/env python3
"""odometry_node.py - our own wheel odometry from /joint_states.

    ros2 run a2_description odometry_node.py --ros-args -p use_sim_time:=true \
        -p r_left:=0.048907 -p r_right:=0.049093 -p b:=0.303 -p method:=exact

Launch the simulation with plugin_tf:=false so that this node is the only
publisher of the odom -> base_link transform.

Each /joint_states message carries the CUMULATIVE wheel angles, so the node
keeps the previous angles and works with their differences:

    dphi_L, dphi_R      change in wheel angle since the last message (rad)
    ds_L = r_L * dphi_L,  ds_R = r_R * dphi_R         wheel travel (m)
    ds     = (ds_R + ds_L) / 2                        distance moved
    dtheta = (ds_R - ds_L) / b                        heading change

and then integrates the pose (x, y, theta) with one of two methods:

    euler   x += ds cos(theta); y += ds sin(theta); theta += dtheta
            (uses the heading at the START of the step)
    exact   the step is a circular arc of radius ds / dtheta, integrated in
            closed form; falls back to the midpoint heading when |dtheta| is
            tiny, where the arc radius blows up.

Parameters:
    r_left, r_right   wheel radii (m)                 default: P06 values
    b                 track width (m)                 default: P06 value
    method            'euler' or 'exact'              default 'exact'
    left_joint, right_joint   joint names             default left/right_wheel_joint
    odom_topic        output topic                    default '/odom_own'
    publish_tf        broadcast odom -> base_link     default true

    ros2 run a2_description odometry_node.py --ros-args -r __node:=odom_exact \
        -p use_sim_time:=true -p method:=exact -p odom_topic:=/odom_exact
    ros2 run a2_description odometry_node.py --ros-args -r __node:=odom_euler \
        -p use_sim_time:=true -p method:=euler -p odom_topic:=/odom_euler -p publish_tf:=false
"""
import math

import rclpy
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import JointState
from tf2_ros import TransformBroadcaster

EXACT_EPS = 1e-6   # |dtheta| below this: use the midpoint (straight-line) form


def step_euler(x, y, th, ds, dth):
    return x + ds * math.cos(th), y + ds * math.sin(th), th + dth


def step_exact(x, y, th, ds, dth):
    if abs(dth) < EXACT_EPS:
        mid = th + 0.5 * dth
        return x + ds * math.cos(mid), y + ds * math.sin(mid), th + dth
    r = ds / dth
    th_new = th + dth
    return (x + r * (math.sin(th_new) - math.sin(th)),
            y - r * (math.cos(th_new) - math.cos(th)),
            th_new)


METHODS = {'euler': step_euler, 'exact': step_exact}


class OdometryNode(Node):
    def __init__(self):
        super().__init__('odometry_node')
        self.r_left = float(self.declare_parameter('r_left', 0.048907).value)
        self.r_right = float(self.declare_parameter('r_right', 0.049093).value)
        self.b = float(self.declare_parameter('b', 0.303).value)
        method = str(self.declare_parameter('method', 'exact').value).lower()
        self.left_joint = str(self.declare_parameter('left_joint', 'left_wheel_joint').value)
        self.right_joint = str(self.declare_parameter('right_joint', 'right_wheel_joint').value)
        odom_topic = str(self.declare_parameter('odom_topic', '/odom_own').value)
        self.publish_tf = bool(self.declare_parameter('publish_tf', True).value)

        if method not in METHODS:
            raise ValueError(f"method must be one of {sorted(METHODS)}, got '{method}'")
        if min(self.r_left, self.r_right, self.b) <= 0.0:
            raise ValueError('r_left, r_right and b must all be > 0')
        self.method = method
        self.step = METHODS[method]

        self.x = self.y = self.th = 0.0
        self.prev = None          # (phi_left, phi_right) from the last message
        self.prev_t = None        # its time in seconds
        self.warned = False

        self.pub = self.create_publisher(Odometry, odom_topic, 10)
        self.tf = TransformBroadcaster(self) if self.publish_tf else None
        self.create_subscription(JointState, '/joint_states', self.on_joints, 50)
        self.get_logger().info(
            f'method={method}, r_left={self.r_left:g}, r_right={self.r_right:g}, '
            f'b={self.b:g}, publishing {odom_topic}'
            f'{"" if self.publish_tf else " (no TF)"}. Waiting for /joint_states ...')

    def on_joints(self, msg):
        try:
            i_l = msg.name.index(self.left_joint)
            i_r = msg.name.index(self.right_joint)
            phi = (msg.position[i_l], msg.position[i_r])
        except (ValueError, IndexError):
            if not self.warned:
                self.get_logger().warn(
                    f"/joint_states has no '{self.left_joint}' / '{self.right_joint}' "
                    f'(names: {list(msg.name)})')
                self.warned = True
            return

        stamp = msg.header.stamp
        if stamp.sec == 0 and stamp.nanosec == 0:
            stamp = self.get_clock().now().to_msg()
        t = stamp.sec + 1e-9 * stamp.nanosec

        if self.prev is None:                  # initialise on the first message
            self.prev, self.prev_t = phi, t
            self.get_logger().info('Initialised; pose starts at (0, 0, 0).')
            return

        ds_l = self.r_left * (phi[0] - self.prev[0])
        ds_r = self.r_right * (phi[1] - self.prev[1])
        ds = 0.5 * (ds_r + ds_l)
        dth = (ds_r - ds_l) / self.b
        self.x, self.y, self.th = self.step(self.x, self.y, self.th, ds, dth)
        dt = t - self.prev_t
        self.prev, self.prev_t = phi, t
        self.publish(stamp, ds / dt if dt > 0 else 0.0, dth / dt if dt > 0 else 0.0)

    def publish(self, stamp, v, w):
        qz, qw = math.sin(0.5 * self.th), math.cos(0.5 * self.th)

        odom = Odometry()
        odom.header.stamp = stamp
        odom.header.frame_id = 'odom'
        odom.child_frame_id = 'base_link'
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.orientation.z = qz
        odom.pose.pose.orientation.w = qw
        odom.twist.twist.linear.x = v
        odom.twist.twist.angular.z = w
        self.pub.publish(odom)

        if self.tf is None:
            return
        tf = TransformStamped()
        tf.header.stamp = stamp
        tf.header.frame_id = 'odom'
        tf.child_frame_id = 'base_link'
        tf.transform.translation.x = self.x
        tf.transform.translation.y = self.y
        tf.transform.rotation.z = qz
        tf.transform.rotation.w = qw
        self.tf.sendTransform(tf)


def main():
    rclpy.init()
    node = OdometryNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
