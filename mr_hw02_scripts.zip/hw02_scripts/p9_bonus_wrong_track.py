#!/usr/bin/env python3
"""
PROBLEM 9 (BONUS) - A wrong track width (simple version, no classes)

Run from hw02_scripts/:
    python3 p9_bonus_wrong_track.py        -> all parts (a b c)
    python3 p9_bonus_wrong_track.py c      -> only part c

Results (spin.csv, spin.png, sim.log) go to results/p9/.
Look for "FILL IN": that is YOUR equation.
"""
import csv, math, os, signal, subprocess, sys, time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

# =====================================================================
# SETTINGS
# =====================================================================
PAIR = "P06"            # your pair ID
SCALES = [0.9, 1.1]     # the plugin is told track width s*b
OMEGAS = [0.5, 1.0]     # turn rates [rad/s]
TRIALS = 3              # trials per combination (2 x 2 x 3 = 12 runs)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "p9")
os.makedirs(OUT, exist_ok=True)


# =====================================================================
# 9(a) YOUR EQUATION - fill this in
# =====================================================================
def predicted_ratio(s, omega):
    """The plugin is told track width s*b. The robot spins until /odom says one
    full turn. Return (true yaw change) / (odom yaw change)."""
  
    ratio = s
  
    return ratio


# =====================================================================
# 9(b) THE SPIN TEST: spin until /odom says one full turn
# =====================================================================
odom_msg = None      # newest /odom message
truth_msg = None     # newest /ground_truth/odom message


def on_odom(msg):
    global odom_msg
    odom_msg = msg


def on_truth(msg):
    global truth_msg
    truth_msg = msg


def get_yaw(msg):
    """Yaw angle from an Odometry message."""
    return 2.0 * math.atan2(msg.pose.pose.orientation.z, msg.pose.pose.orientation.w)


def wrap(angle):
    """Wrap an angle to [-pi, pi]."""
    return math.atan2(math.sin(angle), math.cos(angle))


def spin_test(omega):
    """Spin at omega until /odom says 2*pi, stop, rest 2 s.
    Returns (odom yaw change, true yaw change) in rad."""
    global odom_msg, truth_msg
    odom_msg, truth_msg = None, None

    node = rclpy.create_node("spin_test")
    pub = node.create_publisher(Twist, "/cmd_vel", 10)
    node.create_subscription(Odometry, "/odom", on_odom, 10)
    node.create_subscription(Odometry, "/ground_truth/odom", on_truth, 10)

    total_odom, total_true = 0.0, 0.0      # yaw changes added up (no jump at +-pi)
    prev_odom, prev_true = None, None
    stop_time = None                       # time when the robot was stopped

    while rclpy.ok():
        rclpy.spin_once(node, timeout_sec=0.1)
        if odom_msg is None or truth_msg is None:
            continue
        t = odom_msg.header.stamp.sec + odom_msg.header.stamp.nanosec * 1e-9
        odom_yaw, true_yaw = get_yaw(odom_msg), get_yaw(truth_msg)

        # add up the small yaw changes
        if prev_odom is not None:
            total_odom += wrap(odom_yaw - prev_odom)
            total_true += wrap(true_yaw - prev_true)
        prev_odom, prev_true = odom_yaw, true_yaw

        if stop_time is None:
            if abs(total_odom) >= 2 * math.pi:     # /odom says one full turn: stop
                pub.publish(Twist())
                stop_time = t
            else:                                  # keep spinning
                cmd = Twist()
                cmd.angular.z = omega
                pub.publish(cmd)
        else:
            pub.publish(Twist())
            if t - stop_time >= 2.0:               # rested 2 s: done
                break

    node.destroy_node()
    return total_odom, total_true


# =====================================================================
# GAZEBO: a fresh simulation for every run (no need to read this part)
# =====================================================================
def start_sim(scale):
    cmd = ["ros2", "launch", "a2_description", "sim.launch.py", "pair:=" + PAIR,
           "plugin_separation_scale:=%g" % scale]
    sim = subprocess.Popen(cmd, stdout=open(os.path.join(OUT, "sim.log"), "w"),
                           stderr=subprocess.STDOUT, start_new_session=True)
    t0 = time.time()                               # wait until the simulator is publishing
    while subprocess.run(["timeout", "3", "ros2", "topic", "echo", "--once", "/ground_truth/odom"],
                         capture_output=True).returncode != 0:
        if sim.poll() is not None or time.time() - t0 > 180:
            stop_sim(sim)
            sys.exit("ERROR: Gazebo did not start, see results/p9/sim.log")
        time.sleep(1)
    time.sleep(2)
    return sim


def stop_sim(sim):
    try:
        os.killpg(sim.pid, signal.SIGINT)
        sim.wait(timeout=15)
    except Exception:
        pass
    for name in ["gz sim", "parameter_bridge", "robot_state_publisher",
                 "static_transform_publisher", "path_publisher", "rviz2"]:
        subprocess.run(["pkill", "-f", name])
    time.sleep(2)


# =====================================================================
# PARTS
# =====================================================================
def part_a():
    pass


def part_b():
    print("  the spin test is the function spin_test() above (used in part c)")


def part_c():
    rows = []                                      # [s, omega, trial, odom yaw, true yaw, ratio]
    for s in SCALES:
        for omega in OMEGAS:
            for trial in range(1, TRIALS + 1):
                print("  running scale=%g omega=%g trial=%d" % (s, omega, trial))
                sim = start_sim(s)
                odom_yaw, true_yaw = spin_test(omega)
                stop_sim(sim)
                rows.append([s, omega, trial, odom_yaw, true_yaw, true_yaw / odom_yaw])

    # save the CSV
    with open(os.path.join(OUT, "spin.csv"), "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["scale", "omega", "trial", "odom_yaw", "true_yaw", "ratio"])
        writer.writerows(rows)

    # table
    print("\n  scale | omega | trial | odom yaw [rad] | true yaw [rad] | ratio  | predicted")
    print("  " + "-" * 76)
    for s, omega, trial, odom_yaw, true_yaw, ratio in rows:
        pred = predicted_ratio(s, omega)
        pred = "-" if pred is None else "%.4f" % pred
        print("  %5.2f | %5.1f | %5d | %14.4f | %14.4f | %.4f | %s"
              % (s, omega, trial, odom_yaw, true_yaw, ratio, pred))

    # plot: ratio against omega, one colour per scale
    plt.figure(figsize=(6, 4))
    for s in SCALES:
        plt.plot([r[1] for r in rows if r[0] == s], [r[5] for r in rows if r[0] == s], "o", label="s = %g" % s)
    plt.xlabel("omega [rad/s]")
    plt.ylabel("true yaw / odom yaw")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "spin.png"), dpi=150)
    print("\n  plot saved: results/p9/spin.png")



# =====================================================================
# MAIN
# =====================================================================
PARTS = {"a": part_a, "b": part_b, "c": part_c}

if __name__ == "__main__":
    rclpy.init()
    for part in sys.argv[1:] or PARTS:
        print("\n===== Problem 9(%s) =====" % part)
        PARTS[part]()
    rclpy.shutdown()