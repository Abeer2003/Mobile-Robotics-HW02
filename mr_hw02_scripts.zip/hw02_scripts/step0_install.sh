#!/bin/bash
# =====================================================================
#  STEP 0 - Install tools and build the a2_description package
#
#  How to run:
#     bash step0_install.sh        -> all steps (b, c, d)
#     bash step0_install.sh c      -> only step c (build)
#
#  Inside docker (../run_docker.sh) the tools are already installed,
#  so only step c (build) and step d (check) matter there.
# =====================================================================

# ---------- 1. SETTINGS (edit these) ----------
PAIR="P06"                       # your pair ID (group 11 -> P11)

# ---------- 2. PATHS (normally no need to edit) ----------
HERE="$(cd "$(dirname "$0")" && pwd)"                               # hw02_scripts
A2_SRC="$(dirname "$HERE")"                                            # HW2 folder
HW2="$(dirname "$A2_SRC")"

WS="$HW2/a2_ws"                                                     # colcon workspace



#A2_SRC="$HW2/ece468-mobile-robotics-assignment-2-group-11-main"     # the a2_description package

# ---------- 3. LOAD ROS 2 ----------
source /opt/ros/jazzy/setup.bash

# Use sudo only when we are not root (in docker we may be root)
SUDO=""
if [ "$(id -u)" -ne 0 ]; then SUDO="sudo"; fi

# ROS packages the homework needs
NEEDED="ros_gz_sim ros_gz_bridge xacro robot_state_publisher joint_state_publisher_gui teleop_twist_keyboard tf2_tools rqt_graph rviz2"

# prints the names of the packages from NEEDED that are not installed
missing_packages() {
  for p in $NEEDED; do
    ros2 pkg prefix "$p" > /dev/null 2>&1 || echo -n "$p "
  done
}

# ---------- 6. STEPS ----------

# b) install the ROS packages and python libraries
step_b() {
  echo "=== b) Install extra ROS tools and python libraries ==="
  MISSING=$(missing_packages)
  if [ -z "$MISSING" ]; then
    echo "   all ROS packages are already installed - skipping"
    return
  fi
  echo "   missing: $MISSING"
  if [ -n "$SUDO" ] && ! command -v sudo > /dev/null; then
    echo "ERROR: need root to install. In docker, use:  ../run_docker.sh root"
    exit 1
  fi
  $SUDO apt update
  $SUDO apt install -y \
    ros-jazzy-ros-gz ros-jazzy-xacro ros-jazzy-robot-state-publisher \
    ros-jazzy-teleop-twist-keyboard ros-jazzy-rqt-graph ros-jazzy-tf2-tools \
    ros-jazzy-rviz2 ros-jazzy-joint-state-publisher-gui \
    python3-colcon-common-extensions python3-numpy python3-matplotlib python3-yaml
}

# c) put the package into the workspace (a link, not a copy) and build it
step_c() {
  echo "=== c) Build a2_description ==="
  if [ ! -f "$A2_SRC/package.xml" ]; then
    echo "ERROR: package not found at $A2_SRC"
    exit 1
  fi
  mkdir -p "$WS/src"
  if [ ! -e "$WS/src/a2_description" ]; then
    # relative link, so it works on the host AND inside docker
    ln -s ../../ece468-mobile-robotics-assignment-2-group-11-main "$WS/src/a2_description"
    echo "   linked $WS/src/a2_description -> $A2_SRC"
  fi
  cd "$WS" || exit 1
  colcon build --symlink-install || { echo "ERROR: colcon build failed"; exit 1; }
  echo "   build finished: $WS/install"
}

# d) check that everything is found
step_d() {
  echo "=== d) Check ==="
  source "$WS/install/setup.bash"
  if ros2 pkg prefix a2_description > /dev/null 2>&1; then
    echo "   a2_description OK"
  else
    echo "   a2_description NOT FOUND - run: bash step0_install.sh c"
  fi
  MISSING=$(missing_packages)
  if [ -z "$MISSING" ]; then echo "   ROS packages OK"; else echo "   MISSING: $MISSING"; fi
  command -v gz > /dev/null && echo "   gazebo OK" || echo "   gazebo NOT FOUND"
  python3 -c "import numpy, matplotlib, yaml; print('   python libraries OK')"

  # show your robot's numbers from pairs.yaml
  echo "   your robot ($PAIR) in pairs.yaml:"
  grep -A8 "^  $PAIR:" "$A2_SRC/config/pairs.yaml"
}

# ---------- 7. RUN THE STEPS ----------
STEPS="${*:-b c d}"
for s in $STEPS; do
  "step_$s"
done
