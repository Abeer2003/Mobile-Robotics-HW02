#!/usr/bin/env python3
"""
PROBLEM 10 (BONUS) - Follow a moving target (simple version, no classes)

Run from hw02_scripts/:
    python3 p10_bonus_cone.py        -> all parts (a b c d)
    python3 p10_bonus_cone.py d      -> only part d

Results (csv, png, logs) go to results/p10/.
Look for "FILL IN": that is YOUR equation.
"""
import math, os, signal, subprocess, sys, time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan

# =====================================================================
# SETTINGS
# =====================================================================
PAIR = "P06"            # your pair ID
KP_LIST = [0.5, 1.5]    # part b: the two speed gains kp_v to compare
KP_HUGE = 10.0          # part c: a huge speed gain
KP_D = 1.5              # part d: speed gain for the stopgo and arc profiles
KP_W = 1.5              # turn gain (kept fixed)
D_DES = 0.5             # distance to keep to the cone [m]
CONE_SPEED = 0.2        # cone speed [m/s]
MAX_RANGE = 4.0         # ignore anything further away than this [m]
RUN_TIME = 40.0         # length of each run [simulated seconds]

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "p10")
os.makedirs(OUT, exist_ok=True)



def cone_controller(rho, phi, kp_v, kp_w):
    v = kp_v * (rho - D_DES)
    omega = kp_w * phi
    return v, omega


# =====================================================================
# 10(a) THE CONE FOLLOWER
# =====================================================================
scan_msg = None      # newest /scan message
robot_xy = None      # true robot position (only used for the log)
cone_xy = None       # true cone position (only used for the log)


def on_scan(msg):
    global scan_msg
    scan_msg = msg


def on_robot(msg):
    global robot_xy
    robot_xy = (msg.pose.pose.position.x, msg.pose.pose.position.y)


def on_cone(msg):
    global cone_xy
    cone_xy = (msg.pose.pose.position.x, msg.pose.pose.position.y)


def follow_cone(kp_v, kp_w, csv_file):
    """Follow the cone for RUN_TIME seconds and log t, rho, phi, v, omega, true_dist."""
    global scan_msg, robot_xy, cone_xy
    scan_msg, robot_xy, cone_xy = None, None, None

    node = rclpy.create_node("cone_follower")
    pub = node.create_publisher(Twist, "/cmd_vel", 10)
    node.create_subscription(LaserScan, "/scan", on_scan, 10)
    node.create_subscription(Odometry, "/ground_truth/odom", on_robot, 10)
    node.create_subscription(Odometry, "/cone/ground_truth/odom", on_cone, 10)

    log = []
    t0 = None
    while rclpy.ok():
        rclpy.spin_once(node, timeout_sec=0.1)
        if scan_msg is None:
            continue
        msg, scan_msg = scan_msg, None             # take the new scan and clear it

        # time since the first scan, stop when the time is up
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if t0 is None:
            t0 = t
        t -= t0
        if t > RUN_TIME:
            break

        # the cone is the nearest valid beam (beam i points i degrees counter-clockwise)
        ranges = np.array(msg.ranges)
        valid = np.isfinite(ranges) & (ranges > msg.range_min) & (ranges < MAX_RANGE)

        cmd = Twist()                              # nothing seen: stop
        rho, phi = float("nan"), float("nan")
        if valid.any():
            i = int(np.argmin(np.where(valid, ranges, np.inf)))
            rho = ranges[i]
            phi = math.radians(i if i <= 180 else i - 360)       # -179 ... 180 degrees
            v, omega = cone_controller(rho, phi, kp_v, kp_w)
            cmd.linear.x = max(0.0, min(0.5, v))                 # 0 <= v <= 0.5
            cmd.angular.z = max(-1.5, min(1.5, omega))           # |omega| <= 1.5
        pub.publish(cmd)

        # the TRUE robot-to-cone distance, from ground truth
        true_dist = float("nan")
        if robot_xy and cone_xy:
            true_dist = math.hypot(cone_xy[0] - robot_xy[0], cone_xy[1] - robot_xy[1])
        log.append([t, rho, phi, cmd.linear.x, cmd.angular.z, true_dist])

    pub.publish(Twist())                           # stop the robot
    node.destroy_node()
    np.savetxt(csv_file, np.array(log), delimiter=",", comments="",
               header="t,rho,phi,v,omega,true_dist")


# =====================================================================
# GAZEBO: a fresh simulation for every run (no need to read this part)
# =====================================================================
def start_sim():
    cmd = ["ros2", "launch", "a2_description", "sim.launch.py", "pair:=" + PAIR, "cone:=true"]
    sim = subprocess.Popen(cmd, stdout=open(os.path.join(OUT, "sim.log"), "w"),
                           stderr=subprocess.STDOUT, start_new_session=True)
    t0 = time.time()                               # wait until the simulator is publishing
    while subprocess.run(["timeout", "3", "ros2", "topic", "echo", "--once", "/ground_truth/odom"],
                         capture_output=True).returncode != 0:
        if sim.poll() is not None or time.time() - t0 > 180:
            stop_sim(sim)
            sys.exit("ERROR: Gazebo did not start, see results/p10/sim.log")
        time.sleep(1)
    time.sleep(2)
    return sim


def stop_sim(sim):
    try:
        os.killpg(sim.pid, signal.SIGINT)
        sim.wait(timeout=15)
    except Exception:
        pass
    for name in ["gz sim", "parameter_bridge", "robot_state_publisher",
                 "static_transform_publisher", "path_publisher", "rviz2", "cone_driver"]:
        subprocess.run(["pkill", "-f", name])
    time.sleep(2)


def run_cone(name, profile, kp_v):
    """Gazebo + cone driver + your follower. Returns the csv file."""
    print("  running %-10s profile=%s kp_v=%g" % (name, profile, kp_v))
    csv_file = os.path.join(OUT, name + ".csv")
    sim = start_sim()
    driver = subprocess.Popen(["ros2", "run", "a2_description", "cone_driver.py", "--ros-args",
                               "-p", "use_sim_time:=true", "-p", "profile:=" + profile,
                               "-p", "speed:=%g" % CONE_SPEED],
                              stdout=open(os.path.join(OUT, "cone_driver.log"), "w"),
                              stderr=subprocess.STDOUT)
    follow_cone(kp_v, KP_W, csv_file)
    driver.terminate()
    stop_sim(sim)
    return csv_file


# =====================================================================
# RESULTS: table + plot of rho, phi, v, omega
# =====================================================================
def analyse(csv_files, png_name):
    """Steady state = average of the last 10 s of each run."""
    print("\n  %-10s | %-10s | %-14s | %-10s | %-10s" %
          ("run", "rho lidar", "rho - D_DES", "true dist", "true-lidar"))
    print("  " + "-" * 66)
    fig, axes = plt.subplots(4, 1, figsize=(8, 9), sharex=True)
    for f in csv_files:
        d = np.genfromtxt(f, delimiter=",", names=True)
        last = d["t"] > d["t"].max() - 10.0
        rho = np.nanmean(d["rho"][last])
        true = np.nanmean(d["true_dist"][last])
        print("  %-10s | %-10.4f | %-14.4f | %-10.4f | %-10.4f" %
              (os.path.basename(f)[:-4], rho, rho - D_DES, true, true - rho))
        for ax, column in zip(axes, ["rho", "phi", "v", "omega"]):
            ax.plot(d["t"], d[column], label=os.path.basename(f)[:-4])
            ax.set_ylabel(column)
            ax.grid(True)
    axes[0].axhline(D_DES, c="k", ls="--")
    axes[0].legend()
    axes[-1].set_xlabel("time [s]")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, png_name), dpi=150)
    plt.close(fig)
    print("  plot saved: results/p10/" + png_name)


# =====================================================================
# PARTS, ONE BY ONE
# =====================================================================
def part_a():
    print("  the follower is follow_cone() above; controller is filled in")


def part_b():
    print("  profile 'line' at %g m/s, kp_v in %s" % (CONE_SPEED, KP_LIST))
    files = [run_cone("line_kp%g" % kp, "line", kp) for kp in KP_LIST]
    analyse(files, "line_gains.png")


def part_c():
    print("  profile 'line' with a huge gain kp_v = %g" % KP_HUGE)
    files = [run_cone("line_kp%g" % KP_HUGE, "line", KP_HUGE)]
    analyse(files, "line_huge_gain.png")


def part_d():
    print("  profiles 'stopgo' and 'arc', kp_v = %g" % KP_D)
    files = [run_cone("stopgo", "stopgo", KP_D), run_cone("arc", "arc", KP_D)]
    analyse(files, "stopgo_arc.png")


# =====================================================================
# SIMPLE EXPLANATION (printed at the end)
# =====================================================================
def print_explanation():
    print("""
=====================================================================
  SIMPLE EXPLANATION (assumes v = kp_v * (rho - D_DES): check your plots)
=====================================================================
  10(b) Steady-state error and the LiDAR/truth offset
  - The cone drives at u = %g m/s, so the robot must drive at u too.
    A P controller only makes v when there is an error, so it settles at
    rho - D_DES = u / kp_v. Larger kp_v -> smaller error (u/0.5 = %.2f m,
    u/1.5 = %.2f m).
  - The LiDAR sees the front surface of the cone, but ground truth is the
    cone centre. So true distance = LiDAR rho + about the cone radius.

  10(c) Huge gain, and a better fix
  - A huge gain shrinks the error (u / kp_v), but it amplifies LiDAR noise,
    saturates v at its limits and can make the robot oscillate or hunt.
  - Fix without a high gain: add an I term (it removes the constant error),
    or feed forward the cone speed (estimate it from the change of rho).

  10(d) What the steady-state analysis misses
  - stopgo: when the cone stops, the robot cannot reverse (v >= 0), so it
    can drive too close or overshoot. Each restart has a lag and a new
    transient.
  - arc: the cone keeps turning, so phi stays non-zero and the robot lags
    behind or cuts inside the path. The cone can even leave the LiDAR view.
  - Both are transient or tracking effects. The u / kp_v result only holds
    for a constant-speed straight line.
""" % (CONE_SPEED, CONE_SPEED / 0.5, CONE_SPEED / 1.5))


# =====================================================================
# MAIN
# =====================================================================
PARTS = {"a": part_a, "b": part_b, "c": part_c, "d": part_d}

if __name__ == "__main__":
    if cone_controller(1.0, 0.1, 1.0, 1.0)[0] is None:
        sys.exit("Please fill in cone_controller() first.")

    rclpy.init()
    for part in sys.argv[1:] or PARTS:
        print("\n===== Problem 10(%s) =====" % part)
        PARTS[part]()
    rclpy.shutdown()
    print_explanation()