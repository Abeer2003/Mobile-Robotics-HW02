#!/usr/bin/env python3
"""
PROBLEM 6 - Where is the wall?   [10 pts]

    (a) alpha and D from the two beams  -> checked on a straight wall
    (b) sigma_alpha for theta = 15 ... 75 deg
    (c) how far ahead along the wall beam a lands
    (d), (e) written answers
"""


import math
import sys

import numpy as np

# =====================================================================
# SETTINGS
# =====================================================================
THETA = 45              # angle between the two beams [deg]
D_WALL = 0.8            # distance to the wall [m]  (wall-following start)
SIGMA_R = 0.01          # LiDAR range noise [m]
THETA_LIST = [15, 30, 45, 60, 75]      # angles asked for in (b) [deg]

# The two beams (angles counter-clockwise from the robot's forward axis):
#    beam b = ranges[270]           straight to the right
#    beam a = ranges[270 + THETA]   THETA degrees further forward
BEAM_B = 270
BEAM_A_OFFSET = THETA


def rad(deg):
    return deg*(np.pi/180)



def wall_alpha_D(a, b, theta):
    

    h_square = a**2 + b**2 - 2*a*b*np.cos(theta)
    h = h_square**(1/2)

    gamma = np.arcsin(np.sin(theta) * b / h)

    alpha = 2*np.pi - rad(BEAM_B) - theta - gamma

    D = a * np.sin(gamma)

    return alpha, D


def sigma_alpha(theta, D, sigma_r):
    """Problem 6(b): standard deviation of alpha [rad] when alpha = 0."""
    sigma = sigma_r/D * np.sqrt(1+np.cos(theta)**2)/np.tan(theta)
    return sigma


# =====================================================================
# PRINTING HELPERS
# =====================================================================
def title(text):
    print()
    print("=" * 60)
    print("  " + text)
    print("=" * 60)


def raycast(D, alpha, beam_deg):
    """Range of a beam at beam_deg to a straight wall D metres to the right
    when the robot heading is alpha. Used to test the formula in (a)."""
    angle = alpha + math.radians(beam_deg)
    if math.sin(angle) < 0:
        return -D / math.sin(angle)
    return float("inf")


# =====================================================================
# PARTS
# =====================================================================
def part_a():
    title("6(a)  alpha and D from two beams")
    print("  beam b = %d deg,  beam a = %d deg,  theta = %d deg" % (BEAM_B, BEAM_B + BEAM_A_OFFSET, THETA))
    print("  test: straight wall at D = %.2f m, robot at several headings\n" % D_WALL)
    print("  %12s | %9s %9s | %12s %10s" % ("true alpha", "a [m]", "b [m]", "alpha [deg]", "D [m]"))
    print("  " + "-" * 58)
    for true_alpha in [-20, -10, 0, 10, 25]:
        a = raycast(D_WALL, rad(true_alpha), BEAM_B + BEAM_A_OFFSET)
        b = raycast(D_WALL, rad(true_alpha), BEAM_B)
        alpha, D = wall_alpha_D(a, b, rad(THETA))
        alpha_deg = round(math.degrees(alpha), 2) + 0.0      # + 0.0 avoids printing "-0.00"
        print("  %8d deg | %9.4f %9.4f | %12.2f %10.4f" % (true_alpha, a, b, alpha_deg, D))


def part_b():
    title("6(b)  sigma_alpha at alpha = 0")
    print("  D = %.2f m,  sigma_r = %.2f m\n" % (D_WALL, SIGMA_R))
    print("  %10s | %16s" % ("theta", "sigma_alpha"))
    print("  " + "-" * 29)
    for theta in THETA_LIST:
        sigma = sigma_alpha(rad(theta), D_WALL, SIGMA_R)
        print("  %6d deg | %12.3f deg" % (theta, math.degrees(sigma)))


def part_c():
    title("6(c, d, e)  where beam a lands on the wall")
    print(
        '''
        (c) Two things the noise model leaves out

        Looking too far ahead. Beam a hits the wall about D·tan θ ahead of the robot. At D = 0.8 m that is 0.8 m for 45° but 3 m for 75°. When the wall ends (the doorway or an outside corner), beam a sees the gap first. It returns inf or the far wall, so α and D suddenly jump, and the robot steers the wrong way before it even reaches the gap.
        Real sensors get worse at long range and shallow angles. A large θ means beam a is long and hits the wall at a grazing angle. Real LiDAR is noisier and drops out more in that case. Also, the two beams measure different spots, so a bump in the wall looks like a heading error.

        (d) Does agreement with the simulator prove (b) is right?

        No. The simulator uses the same noise model that (b) assumes, so they must agree. It only checks my algebra, not whether the noise model matches a real LiDAR, where noise depends on range and angle.

        (e) Choice of θ

        I choose θ = 45°, with beam b at 270° and beam a at 315°. It gives σα of about 0.9°, much better than 3.7° at 15°, while beam a only looks about 0.8 m ahead. Larger angles reduce the noise only slightly more but look much farther ahead, which causes trouble at the doorway and corners.

        '''
    )


# =====================================================================
# MAIN
# =====================================================================
PARTS = {"a": part_a, "b": part_b, "c": part_c}

if __name__ == "__main__":
    for name in sys.argv[1:] or list(PARTS):
        PARTS[name]()
    print()



