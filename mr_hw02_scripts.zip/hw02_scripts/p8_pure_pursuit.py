#!/usr/bin/env python3
"""
PROBLEM 8 - Follow a path: pure pursuit (beginner version)

Run from hw02_scripts/:
    python3 p8_pure_pursuit.py        -> all parts (a b c d)
    python3 p8_pure_pursuit.py c      -> only part c

Every lap restarts Gazebo and saves name.csv. Every part saves one PNG.
Results go to results/p8/.   Look for "FILL IN": those are YOUR equations.
"""
import math, os, signal, subprocess, sys, time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import rclpy
from ament_index_python.packages import get_package_share_directory
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

# =====================================================================
# SETTINGS
# =====================================================================
PAIR = "P06"        # your pair ID
V = 0.2             # forward speed [m/s]
W_MAX = 1.5         # turn rate limit [rad/s]
TIMEOUT = 200.0     # stop a lap after this many seconds

# Each part is a list of laps: (name, robot, path, lookahead Ld in m)
RUNS = {
    "b": [("circle_REF", "REF", "circle", 0.5),
          ("circle_pair", PAIR, "circle", 0.5)],
    "c": [("square_REF_ld0.3", "REF", "square", 0.3),
          ("square_REF_ld0.6", "REF", "square", 0.6),
          ("square_REF_ld1", "REF", "square", 1.0),
          ("square_REF_ld0.15", "REF", "square", 0.15)],   # the "too small" lookahead
    "d": [("square_pair", PAIR, "square", 0.3)],
}

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "p8")
os.makedirs(OUT, exist_ok=True)


# =====================================================================
# 8(a) EQUATIONS
# =====================================================================
def to_robot_frame(x_goal, y_goal, x_robot, y_robot, theta):
    
    
    # 1) shift so the robot is at the origin
    dx = x_goal - x_robot
    dy = y_goal - y_robot

    # 2) rotate by -theta so the robot's heading points along +x
    x_r = math.cos(theta) * dx + math.sin(theta) * dy
    y_r = -math.sin(theta) * dx + math.cos(theta) * dy
    
    return x_r, y_r


def curvature(x_r, y_r):
    
    d = x_r**2 + y_r**2          # squared distance to the goal

    r = d / (2 * y_r) 
    kappa = 1/r

    
    return kappa


def turn_rate(v, kappa):
    
    omega = v * kappa
    
    return omega


# =====================================================================
# 8(c) EQUATION
# =====================================================================
def min_lookahead(v, w_max):
    """The lookahead Ld [m] below which a 90-degree square corner demands
    more turn rate than w_max."""
    # ===== FILL IN =====

    r = v/w_max

    Ld = r * np.sqrt(2)
    # ===================
    return Ld


# =====================================================================
# (a) THE PURE PURSUIT CONTROLLER
# =====================================================================
odom_msg = None      # newest /odom message (what the robot believes)
truth_msg = None     # newest /ground_truth/odom message (only used for the log)


def on_odom(msg):
    global odom_msg
    odom_msg = msg


def on_truth(msg):
    global truth_msg
    truth_msg = msg


def get_pose(msg):
    """x, y, heading from an Odometry message."""
    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y
    theta = 2.0 * math.atan2(msg.pose.pose.orientation.z, msg.pose.pose.orientation.w)
    return x, y, theta


def distance_to_path(path, x, y):
    """Cross-track error: distance from (x, y) to the closest waypoint."""
    return np.min(np.hypot(path[:, 0] - x, path[:, 1] - y))


def drive_one_lap(path_name, lookahead):
    """Follow the path for one lap. Returns the log: [t, odom x, odom y, true x, true y,
    error by odom, error by truth, omega] for every step."""
    global odom_msg, truth_msg
    odom_msg, truth_msg = None, None

    # the waypoints: columns x, y, yaw
    file = os.path.join(get_package_share_directory("a2_description"), "paths", path_name + ".csv")
    path = np.loadtxt(file, delimiter=",", skiprows=1)

    node = rclpy.create_node("pure_pursuit")
    pub = node.create_publisher(Twist, "/cmd_vel", 10)
    node.create_subscription(Odometry, "/odom", on_odom, 10)
    node.create_subscription(Odometry, "/ground_truth/odom", on_truth, 10)

    log = []
    index = 0           # nearest waypoint so far (it only moves forward)
    t0 = None

    while rclpy.ok():
        rclpy.spin_once(node, timeout_sec=0.1)
        if odom_msg is None or truth_msg is None:
            continue
        msg, odom_msg = odom_msg, None            # take the new message and clear it

        # time since the first message
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if t0 is None:
            t0 = t
        t = t - t0

        # where the robot thinks it is, and where it really is
        x, y, theta = get_pose(msg)
        true_x, true_y, _ = get_pose(truth_msg)

        # 1) nearest waypoint (search forward only, so it never jumps back at a corner)
        ahead = path[index:index + 300]
        index += int(np.argmin(np.hypot(ahead[:, 0] - x, ahead[:, 1] - y)))

        # lap finished (or too slow): stop
        if index >= len(path) - 3 or t > TIMEOUT:
            break

        # 2) goal point: the first waypoint ahead that is at least `lookahead` away
        rest = path[index:]
        far = np.where(np.hypot(rest[:, 0] - x, rest[:, 1] - y) >= lookahead)[0]
        goal = rest[far[0]] if len(far) > 0 else rest[-1]

        # 3) goal in the robot frame, 4) curvature of the arc, 5) turn rate
        x_r, y_r = to_robot_frame(goal[0], goal[1], x, y, theta)
        kappa = curvature(x_r, y_r)
        omega = turn_rate(V, kappa)
        omega = max(-W_MAX, min(W_MAX, omega))

        # send the command
        cmd = Twist()
        cmd.linear.x = V
        cmd.angular.z = omega
        pub.publish(cmd)

        log.append([t, x, y, true_x, true_y,
                    distance_to_path(path, x, y), distance_to_path(path, true_x, true_y), omega])

    for _ in range(5):                            # stop the robot
        pub.publish(Twist())
    node.destroy_node()
    return log


# =====================================================================
# GAZEBO: a fresh simulation for every lap (no need to read this part)
# =====================================================================
def start_sim(pair, path_name):
    cmd = ["ros2", "launch", "a2_description", "sim.launch.py", "pair:=" + pair, "path:=" + path_name]
    sim = subprocess.Popen(cmd, stdout=open(os.path.join(OUT, "sim.log"), "w"),
                           stderr=subprocess.STDOUT, start_new_session=True)
    t0 = time.time()                              # wait until the simulator is publishing
    while subprocess.run(["timeout", "3", "ros2", "topic", "echo", "--once", "/ground_truth/odom"],
                         capture_output=True).returncode != 0:
        if sim.poll() is not None or time.time() - t0 > 180:
            stop_sim(sim)
            sys.exit("ERROR: Gazebo did not start, see results/p8/sim.log")
        time.sleep(1)
    time.sleep(2)
    return sim


def stop_sim(sim):
    try:
        os.killpg(sim.pid, signal.SIGINT)
        sim.wait(timeout=15)
    except Exception:
        pass
    for name in ["gz sim", "parameter_bridge", "robot_state_publisher",
                 "static_transform_publisher", "path_publisher", "rviz2"]:
        subprocess.run(["pkill", "-f", name])
    time.sleep(2)


def run_lap(name, pair, path_name, lookahead):
    """Start Gazebo, drive one lap, stop Gazebo, save the log to name.csv."""
    print("  running %-18s robot=%s path=%s Ld=%g" % (name, pair, path_name, lookahead))
    sim = start_sim(pair, path_name)
    log = drive_one_lap(path_name, lookahead)
    stop_sim(sim)
    csv_file = os.path.join(OUT, name + ".csv")
    np.savetxt(csv_file, np.array(log), delimiter=",", comments="",
               header="t,odom_x,odom_y,true_x,true_y,error_odom,error_true,omega")
    return csv_file


# =====================================================================
# RESULTS: table + plot (path on the left, cross-track error on the right)
# =====================================================================
def report(runs, path_name, png_name):
    """runs = list of (name, csv_file)."""
    file = os.path.join(get_package_share_directory("a2_description"), "paths", path_name + ".csv")
    reference = np.loadtxt(file, delimiter=",", skiprows=1)

    print("\n  %-18s | %-14s | %-14s | %-14s | %-14s" %
          ("run", "mean error odom", "mean error true", "max error true", "end point off"))
    print("  " + "-" * 86)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 6))
    ax1.plot(reference[:, 0], reference[:, 1], "k--", label="reference")

    for name, csv_file in runs:
        d = np.genfromtxt(csv_file, delimiter=",", names=True)
        late = d["t"] > 5.0                                 # skip the start-up
        end_off = math.hypot(d["true_x"][-1] - reference[0, 0], d["true_y"][-1] - reference[0, 1])
        print("  %-18s | %-14.4f | %-14.4f | %-14.4f | %-14.4f" % (
            name, d["error_odom"][late].mean(), d["error_true"][late].mean(),
            d["error_true"].max(), end_off))
        ax1.plot(d["odom_x"], d["odom_y"], label="/odom " + name)
        ax1.plot(d["true_x"], d["true_y"], ":", label="true " + name)
        ax2.plot(d["t"], d["error_odom"], label="odom " + name)
        ax2.plot(d["t"], d["error_true"], ":", label="true " + name)

    ax1.set_aspect("equal")
    ax1.set_xlabel("x [m]")
    ax1.set_ylabel("y [m]")
    ax1.grid(True)
    ax1.legend(fontsize=7)
    ax2.set_xlabel("time [s]")
    ax2.set_ylabel("cross-track error [m]")
    ax2.grid(True)
    ax2.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, png_name), dpi=150)
    plt.close(fig)
    print("  plot saved: results/p8/" + png_name)


# =====================================================================
# MAIN: every part is "run the laps, then report"
# =====================================================================
if __name__ == "__main__":
    # the controller needs your equations from 8(a)
    if (to_robot_frame(1.0, 1.0, 0.0, 0.0, 0.0)[0] is None
            or curvature(0.5, 0.1) is None or turn_rate(V, 1.0) is None):
        sys.exit("Please fill in to_robot_frame(), curvature() and turn_rate() first.")

    rclpy.init()
    for part in sys.argv[1:] or ["a", "b", "c", "d"]:
        print("\n===== Problem 8(%s) =====" % part)
        if part == "a":
            print("  the controller is drive_one_lap(); equations are filled in")
            continue

        runs = [(name, run_lap(name, pair, path, ld)) for name, pair, path, ld in RUNS[part]]
        report(runs, RUNS[part][0][2], "part_%s.png" % part)

        if part == "c":
            Ld = min_lookahead(V, W_MAX)
            if Ld is None:
                print("\n  Please fill in min_lookahead()")
            else:
                print("\n  YOUR min_lookahead(v=%g, w_max=%g) = %.3f m" % (V, W_MAX, Ld))
    rclpy.shutdown()