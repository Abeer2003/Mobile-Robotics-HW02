#!/usr/bin/env python3
"""
PROBLEM 7 - Follow the wall (simple version, no classes)

Run from hw02_scripts/:
    python3 p7_follow_wall.py        -> all parts (b c d e)
    python3 p7_follow_wall.py b      -> only part b

Each run restarts Gazebo, then saves a CSV and a plot into results/p7/.
"""
import csv, math, os, signal, subprocess, sys, time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import rclpy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

from p6_where_is_wall import wall_alpha_D

# ---------------------------------------------------------------
# SETTINGS
# ---------------------------------------------------------------
THETA = 45          # angle between the two beams [deg]
D_REF = 0.5         # wanted distance to the wall [m] (robot starts at 0.8 m)
V = 0.2             # forward speed [m/s]
W_MAX = 1.5         # turn rate limit [rad/s]
START = (-4.0, -5.2, 0.12)   # wall-following start pose x, y, z

# Each part is a list of runs: (name, Kp, Kd, Ki, run time in seconds)
RUNS = {
    "b": [("P_kp0.5", 0.5, 0, 0, 25), ("P_kp1", 1.0, 0, 0, 25), ("P_kp2", 2.0, 0, 0, 25)],
    "c": [("PD_kd0.2", 1.0, 0.2, 0, 25), ("PD_kd0.5", 1.0, 0.5, 0, 25), ("PD_kd1", 1.0, 1.0, 0, 25)],
    "d": [("PD_best", 1.0, 0.5, 0, 25)],
    "e": [("fail", 1.0, 0.5, 0, 150)],      # long run: doorway, then buttress
}

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "p7")
os.makedirs(OUT, exist_ok=True)


# ---------------------------------------------------------------
# (a) THE WALL FOLLOWER
# ---------------------------------------------------------------

D_REF = 0.3 
def follow_wall(kp, kd, ki, run_time, csv_file):
    """Drive along the wall for run_time seconds and log t, D, alpha, e, omega."""
    node = rclpy.create_node("wall_follower")
    pub = node.create_publisher(Twist, "/cmd_vel", 10)
    log = []
    s = {"t0": None, "prev_t": None, "prev_e": 0.0, "integral": 0.0, "done": False}

    def on_scan(msg):
        # time since the first scan
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if s["t0"] is None:
            s["t0"] = t
        t -= s["t0"]

        # time is up: stop the robot
        if t > run_time:
            pub.publish(Twist())
            s["done"] = True
            return

        # the two beams: b looks straight right, a is THETA degrees ahead of it
        b = msg.ranges[270]
        a = msg.ranges[(270 + THETA) % 360]

        cmd = Twist()
        cmd.linear.x = V
        if not (math.isfinite(a) and math.isfinite(b)):   # no wall seen: go straight
            pub.publish(cmd)
            return

        # distance and angle to the wall (Problem 6)
        alpha, D = wall_alpha_D(a, b, math.radians(THETA))

        # error: negative when too far from the wall or pointing away from it,
        # which turns the robot right, toward the wall
        e = (D_REF - D) - alpha

        # derivative and integral of e
        de_dt = 0.0
        if s["prev_t"] is not None and t > s["prev_t"]:
            dt = t - s["prev_t"]
            de_dt = (e - s["prev_e"]) / dt
            s["integral"] += e * dt
        s["prev_t"], s["prev_e"] = t, e

        # PID, limited to +-W_MAX
        omega = kp * e + kd * de_dt + ki * s["integral"]
        omega = max(-W_MAX, min(W_MAX, omega))

        cmd.angular.z = omega
        pub.publish(cmd)
        log.append([t, D, alpha, e, omega])

    node.create_subscription(LaserScan, "/scan", on_scan, 10)
    while rclpy.ok() and not s["done"]:
        rclpy.spin_once(node, timeout_sec=0.1)
    node.destroy_node()

    with open(csv_file, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["t", "D", "alpha", "e", "omega"])
        writer.writerows(log)


# ---------------------------------------------------------------
# GAZEBO: a fresh simulation for every run
# ---------------------------------------------------------------
def start_sim():
    cmd = ["ros2", "launch", "a2_description", "sim.launch.py", "pair:=P06",
           "x:=%g" % START[0], "y:=%g" % START[1], "z:=%g" % START[2]]
    sim = subprocess.Popen(cmd, stdout=open(os.path.join(OUT, "sim.log"), "w"),
                           stderr=subprocess.STDOUT, start_new_session=True)
    # wait until the simulator is publishing
    t0 = time.time()
    while subprocess.run(["ros2", "topic", "echo", "--once", "/ground_truth/odom"],
                         capture_output=True).returncode != 0:
        if sim.poll() is not None or time.time() - t0 > 180:
            stop_sim(sim)
            sys.exit("ERROR: Gazebo did not start, see results/p7/sim.log")
        time.sleep(1)
    time.sleep(2)
    return sim


def stop_sim(sim):
    try:
        os.killpg(sim.pid, signal.SIGINT)
        sim.wait(timeout=15)
    except Exception:
        pass
    for name in ["gz sim", "parameter_bridge", "robot_state_publisher",
                 "static_transform_publisher", "rviz2"]:
        subprocess.run(["pkill", "-f", name])


def run_test(name, kp, kd, ki, run_time):
    print("  running %-9s Kp=%g Kd=%g Ki=%g (%g s)" % (name, kp, kd, ki, run_time))
    csv_file = os.path.join(OUT, name + ".csv")
    sim = start_sim()
    follow_wall(kp, kd, ki, run_time, csv_file)
    stop_sim(sim)
    return csv_file


# ---------------------------------------------------------------
# RESULTS: table + plot of D and omega against time
# ---------------------------------------------------------------
def report(runs, png_name):
    """Print overshoot, settling time and remaining error. Returns the remaining errors."""
    print("\n  %-10s | %13s | %15s | %17s" % ("run", "overshoot [m]", "settle 2 cm [s]", "remaining err [m]"))
    print("  " + "-" * 64)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 6), sharex=True)
    remaining_errors = []

    for name, csv_file in runs:
        d = np.genfromtxt(csv_file, delimiter=",", names=True)
        t, D, omega = d["t"], d["D"], d["omega"]
        err = D - D_REF

        # overshoot: how far D goes below D_REF after first reaching it (it starts above)
        crossed = np.where(D <= D_REF)[0]
        overshoot = D_REF - D[crossed[0]:].min() if len(crossed) else 0.0

        # settling time: the last moment the error is bigger than 2 cm
        outside = np.where(np.abs(err) > 0.02)[0]
        if len(outside) == 0:
            settle = "0.0"
        elif outside[-1] == len(t) - 1:
            settle = "never"
        else:
            settle = "%.1f" % t[outside[-1]]

        # remaining error: average over the last 5 seconds
        remaining = err[t > t[-1] - 5.0].mean()
        remaining_errors.append(remaining)

        print("  %-10s | %13.3f | %15s | %17.4f" % (name, overshoot, settle, remaining))
        ax1.plot(t, D, label=name)
        ax2.plot(t, omega, lw=0.8, label=name)

    ax1.axhline(D_REF, color="k", ls="--")
    ax1.axhspan(D_REF - 0.02, D_REF + 0.02, color="gray", alpha=0.2)
    ax1.set_ylabel("D [m]")
    ax1.legend()
    ax1.grid(True)
    ax2.set_ylabel("omega [rad/s]")
    ax2.set_xlabel("time [s]")
    ax2.grid(True)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, png_name), dpi=150)
    plt.close(fig)
    print("  plot saved: results/p7/" + png_name)
    return remaining_errors


# ---------------------------------------------------------------
# MAIN: parts (b) to (e) are all "run the tests, then report"
# ---------------------------------------------------------------
if __name__ == "__main__":
    rclpy.init()
    for part in sys.argv[1:] or RUNS:
        print("\n===== Problem 7(%s) =====" % part)
        runs = [(name, run_test(name, kp, kd, ki, T)) for name, kp, kd, ki, T in RUNS[part]]
        remaining = report(runs, "part_%s.png" % part)

        if part == "d":
            print("\n  steady-state error = %.4f m   (LiDAR noise sigma_r = 0.01 m)" % remaining[0])
            print("  Compare this with the error your Kp predicts for the wheel disturbance.")
        if part == "e":
            print("\n  Watch where D and omega jump in the plot: that is where beam a")
            print("  (THETA deg ahead) first sees the doorway gap or the buttress.")
    rclpy.shutdown()